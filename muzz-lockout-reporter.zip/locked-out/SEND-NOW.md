# Put Lockout Reporter out · do this afternoon

Cursor contacts **no one**. You send. About **20 minutes**.

---

## A · Live URL (10 minutes)

The page is already a folder. You do not need git for this step.

1. Open a browser.
2. Go to **https://app.netlify.com/drop** (or Cloudflare Pages “Upload assets” if you prefer).
3. Drag this whole folder onto the drop zone:

   `/home/mdc/muzz-climb/docs/locked-out`

4. Wait for the random URL. Copy it. Example shape: `https://something.netlify.app`
5. Open that URL. Check: Limits open, Bot death-spiral step works, footer shows free + MUZZ + Cursor.
6. Paste the URL into the blanks below as **URL**.

Optional later: point a domain you own at that site. Not required today.

---

## B · One email · IDCARE first (5 minutes)

Open your mail. New message.

**To:** use the contact path on https://www.idcare.org/ (organisation / partner enquiry — do not invent an address; pick the form or the business line they publish).

**Subject:** Free Lockout Reporter for people stuck in bot help-desks — MUZZ AI PTY LTD

**Body:** paste this, then put your URL in both places:

```
Hello,

I am Murray Clode at MUZZ AI PTY LTD (Australia).

We have built a free Lockout Reporter for people locked out of accounts and stuck in bot help-desk loops. Nothing they type leaves their browser. There is no account and no payment.

Live page: URL
Agency note: URL/agency.html
(Or attach the zip: ~/Downloads/muzz-lockout-reporter.zip)

You may link to it or host the files yourselves with the credit on the page: MUZZ AI PTY LTD, Australia · Built by Cursor.

It is not legal advice and not account recovery. It helps a person write the bot death-spiral, ask the company for its security records, and take a summary to the right regulator.

Happy to answer questions. I am the only contact for this — please do not expect a Cursor or Claude account to reply.

Murray Clode
MUZZ AI PTY LTD
Australia
```

Attach from the same folder if useful: `AGENCY-NOTE.md`, `LICENSE`, `index.html`.

---

## C · Same email · three more doors (5 minutes)

Same subject and body. Change only the greeting if you want. Send to:

1. **Scamwatch / National Anti-Scam Centre** — use the contact or partner path on scamwatch.gov.au (not the scam-report form as your channel).
2. **OAIC** — general enquiries / tools for the public (not a privacy complaint about yourselves). Point them at the tool as something complainants can use before or beside a complaint.
3. **Adrian** (firm channel) — short add-on: “Free handout for clients locked out of vendor accounts. Second Key is the paid product later. URL.”

Stop there today. Do not start a media blast.

---

## D · After they reply

- If they ask to host: send the folder zip (`index.html`, `jurisdictions.json`, `LICENSE`, `AGENCY-NOTE.md`).
- If they ask “is this legal advice?”: no — Limits on the page already say that.
- Lawyer on letter templates: still do before any big campaign; do not block IDCARE’s first look.
